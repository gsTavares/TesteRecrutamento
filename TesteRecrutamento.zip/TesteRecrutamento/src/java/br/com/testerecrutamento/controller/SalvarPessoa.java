/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testerecrutamento.controller;

import br.com.testerecrutamento.dao.CidadeDAO;
import br.com.testerecrutamento.dao.PessoaDAO;
import br.com.testerecrutamento.model.Cidade;
import br.com.testerecrutamento.model.Pessoa;
import br.com.testerecrutamento.util.Conversao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author PICHAU
 */
@WebServlet(name = "SalvarPessoa", urlPatterns = {"/SalvarPessoa"})
public class SalvarPessoa extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String msg = "";
        String nomeCidade = "";

        Pessoa oPessoa = new Pessoa();

        oPessoa.setNomePessoa(request.getParameter("nomePessoa"));
        oPessoa.setDataNascimentoPessoa(Conversao.converterData(request.getParameter("dataNascimentoPessoa")));
        oPessoa.setCpfPessoa(request.getParameter("cpfPessoa"));

        // Variável que armazena o nome da cidade da pessoa
        nomeCidade = request.getParameter("cidadePessoa");

        if (request.getParameter("idPessoa").equals("")) {
            try {
                
                PessoaDAO daoPessoa = new PessoaDAO();

                if (daoPessoa.cadastrarPessoa(oPessoa, nomeCidade)) {
                    msg = "Pessoa cadastrada com sucesso";

                    System.out.println("Pessoa cadastrada com sucesso!");
                } else {

                    msg = "Erro ao cadastrar pessoa. CPF inserido possivelmente já cadastrado no sistema.";

                    System.out.println("Erro ao cadastrar pessoa. CPF inserido possivelmente já cadastrado no sistema.");
                }

            } catch (Exception e) {
                System.out.println("Erro ao cadastrar pessoa\nErro: " + e.getMessage());
                e.printStackTrace();
            }
        } else if (!request.getParameter("idPessoa").equals("")) {

            oPessoa.setIdPessoa(Integer.parseInt(request.getParameter("idPessoa")));

            try {
                
                PessoaDAO daoPessoa = new PessoaDAO();

                if (daoPessoa.alterarPessoa(oPessoa, nomeCidade)) {

                    msg = "Pessoa alterada com sucesso";

                    System.out.println("Pessoa alterada com sucesso");
                } else {
                    System.out.println("Erro ao alterar pessoa.");

                    msg = "Erro ao alterar pessoa. Caso seja uma alteração no CPF, verifique se o mesmo não corresponde ao de outra pessoa cadastrada.";
                }

            } catch (Exception e) {
                System.out.println("Erro ao alterar pessoa \nErro: " + e.getMessage());
                e.printStackTrace();
            }

        }

        request.setAttribute("msg", msg);
        request.getRequestDispatcher("ListarPessoas").forward(request, response);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
