/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testerecrutamento.dao;

import br.com.testerecrutamento.model.Pessoa;
import br.com.testerecrutamento.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class PessoaDAO {

    private Connection conn;

    public PessoaDAO() throws Exception {
        try {

            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso");

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }

    }

    public boolean cadastrarPessoa(Object object, String nomeCidade) {

        Pessoa oPessoa = (Pessoa) object;
        PreparedStatement stmt = null;

        String sql = "insert into pessoa(idcidade, nomepessoa, datanascimentopessoa, cpfpessoa)values(?,?,?,?)";

        if (!this.verificarCpf(oPessoa.getCpfPessoa())) {
            return false;
        } else {
            try {
                stmt = this.conn.prepareStatement(sql);

                try {
                    stmt.setInt(1, new CidadeDAO().salvarCidade(nomeCidade));
                } catch (Exception e) {
                    System.out.println("Erro ao salvar/recuperar cidade\nErro: " + e.getMessage());
                    e.printStackTrace();
                }

                stmt.setString(2, oPessoa.getNomePessoa());
                stmt.setDate(3, new java.sql.Date(oPessoa.getDataNascimentoPessoa().getTime()));
                stmt.setString(4, oPessoa.getCpfPessoa());

                stmt.execute();

            } catch (Exception e) {
                System.out.println("Erro ao cadastrar pessoa \nErro: " + e.getMessage());
                e.printStackTrace();

                return false;
            } finally {
                try {
                    ConnectionFactory.fechar(conn, stmt);
                } catch (Exception e) {
                    System.out.println("Erro ao fechar conexão com o BD\nErro: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }

        return true;

    }

    public boolean verificarCpf(String cpfPessoa) {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        String verificacao = "select idpessoa from pessoa where cpfpessoa = ?";

        try {

            stmt = this.conn.prepareStatement(verificacao);

            stmt.setString(1, cpfPessoa);

            rs = stmt.executeQuery();

            if (rs.next()) {
                return false;
            } else {
                return true;
            }

        } catch (Exception e) {
            System.out.println("Erro ao verificar cpf \nErro: " + e.getMessage());
            e.printStackTrace();

            return false;
        }

    }

    public boolean alterarPessoa(Object object, String nomeCidade) {
        Pessoa oPessoa = (Pessoa) object;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String updatePessoa = "update pessoa set idcidade = ?, nomepessoa = ?, datanascimentopessoa = ?, cpfpessoa = ? where idpessoa = ?";
        String consultaCpf = "select cpfpessoa from pessoa where idpessoa = ?";

        try {

            stmt = this.conn.prepareStatement(consultaCpf);
            stmt.setInt(1, oPessoa.getIdPessoa());
            rs = stmt.executeQuery();

            if (rs.next()) {

                if (oPessoa.getCpfPessoa().equals(rs.getString("cpfpessoa"))) {
                    try {

                        stmt = this.conn.prepareStatement(updatePessoa);

                        try {
                            stmt.setInt(1, new CidadeDAO().salvarCidade(nomeCidade));
                        } catch (Exception e) {
                            System.out.println("Erro ao salvar/recuperar cidade\nErro: " + e.getMessage());
                            e.printStackTrace();
                        }

                        stmt.setString(2, oPessoa.getNomePessoa());
                        stmt.setDate(3, new java.sql.Date(oPessoa.getDataNascimentoPessoa().getTime()));
                        stmt.setString(4, oPessoa.getCpfPessoa());
                        stmt.setInt(5, oPessoa.getIdPessoa());

                        stmt.execute();

                    } catch (Exception e) {
                        System.out.println("Erro ao alterar pessoa \nErro: " + e.getMessage());
                        e.printStackTrace();

                        return false;
                    }
                } else if (!oPessoa.getCpfPessoa().equals(rs.getString("cpfpessoa"))) {

                    if (!this.verificarCpf(oPessoa.getCpfPessoa())) {
                        return false;
                    } else {
                        try {

                            stmt = this.conn.prepareStatement(updatePessoa);

                            try {
                                stmt.setInt(1, new CidadeDAO().salvarCidade(nomeCidade));
                            } catch (Exception e) {
                                System.out.println("Erro ao salvar/recuperar cidade\nErro: " + e.getMessage());
                                e.printStackTrace();
                            }

                            stmt.setString(2, oPessoa.getNomePessoa());
                            stmt.setDate(3, new java.sql.Date(oPessoa.getDataNascimentoPessoa().getTime()));
                            stmt.setString(4, oPessoa.getCpfPessoa());
                            stmt.setInt(5, oPessoa.getIdPessoa());

                            stmt.execute();

                        } catch (Exception e) {
                            System.out.println("Erro ao alterar pessoa \nErro: " + e.getMessage());
                            e.printStackTrace();
                            return false;
                        }
                    }

                }
            }

        } catch (Exception e) {
            System.out.println("Erro ao alterar pessoa \nErro: " + e.getMessage());
            e.printStackTrace();
            return false;
            
        } finally {
            try {

                ConnectionFactory.fechar(conn, stmt, rs);

            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão com o BD\nErro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return true;

    }

    public List<Object> listarPessoas() {

        List<Object> listaPessoas = new ArrayList<>();

        PreparedStatement stmt = null;
        ResultSet rs = null;

        String selectPessoas = "select * from pessoa order by nomepessoa";

        try {

            stmt = this.conn.prepareStatement(selectPessoas);

            rs = stmt.executeQuery();

            while (rs.next()) {

                Pessoa oPessoa = new Pessoa();

                oPessoa.setIdPessoa(rs.getInt("idpessoa"));
                oPessoa.setIdCidade(rs.getInt("idcidade"));
                oPessoa.setNomePessoa(rs.getString("nomepessoa"));
                oPessoa.setDataNascimentoPessoa(rs.getDate("datanascimentopessoa"));
                oPessoa.setCpfPessoa(rs.getString("cpfpessoa"));

                listaPessoas.add(oPessoa);

            }

        } catch (Exception e) {
            System.out.println("Erro ao listar pessoas\nErro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {

                ConnectionFactory.fechar(conn, stmt, rs);

            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão com o banco\nErro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return listaPessoas;
    }

    public Object carregarPessoa(int idPessoa) {

        Pessoa oPessoa = null;
        PreparedStatement stmt = null;

        ResultSet rs = null;

        String selectPessoa = "select * from pessoa where idpessoa = ?";

        try {

            stmt = this.conn.prepareStatement(selectPessoa);
            stmt.setInt(1, idPessoa);

            rs = stmt.executeQuery();
            if (rs.next()) {
                oPessoa = new Pessoa();

                oPessoa.setIdPessoa(rs.getInt("idpessoa"));
                oPessoa.setIdCidade(rs.getInt("idcidade"));
                oPessoa.setNomePessoa(rs.getString("nomepessoa"));
                oPessoa.setDataNascimentoPessoa(rs.getDate("datanascimentopessoa"));
                oPessoa.setCpfPessoa(rs.getString("cpfpessoa"));
            }

        } catch (Exception e) {
            System.out.println("Erro ao carregar pessoa\nErro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {

                ConnectionFactory.fechar(conn, stmt, rs);

            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão com o BD\nErro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return oPessoa;

    }
    
    public Object carregarPessoaPorCpf(String cpfPessoa) {

        Pessoa oPessoa = null;
        PreparedStatement stmt = null;

        ResultSet rs = null;

        String selectPessoa = "select * from pessoa where cpfPessoa = ?";

        try {

            stmt = this.conn.prepareStatement(selectPessoa);
            stmt.setString(1, cpfPessoa);

            rs = stmt.executeQuery();
            if (rs.next()) {
                oPessoa = new Pessoa();

                oPessoa.setIdPessoa(rs.getInt("idpessoa"));
                oPessoa.setIdCidade(rs.getInt("idcidade"));
                oPessoa.setNomePessoa(rs.getString("nomepessoa"));
                oPessoa.setDataNascimentoPessoa(rs.getDate("datanascimentopessoa"));
                oPessoa.setCpfPessoa(rs.getString("cpfpessoa"));
            }

        } catch (Exception e) {
            System.out.println("Erro ao carregar pessoa\nErro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {

                ConnectionFactory.fechar(conn, stmt, rs);

            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão com o BD\nErro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return oPessoa;

    }
    
    public void excluirPessoa(int idPessoa){
        
        PreparedStatement stmt = null;
        String delete = "delete from pessoa where idpessoa = ?";
        
        try {
            stmt = this.conn.prepareStatement(delete);
            
            stmt.setInt(1, idPessoa);
            
            stmt.execute();
            
        } catch (Exception e) {
            System.out.println("Erro ao excluir pessoa\nErro: "+e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                
                ConnectionFactory.fechar(conn, stmt);
                
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão com o BD\nErro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
        
    }

}
