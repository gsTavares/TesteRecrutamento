/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testerecrutamento.dao;

import br.com.testerecrutamento.model.Cidade;
import br.com.testerecrutamento.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PICHAU
 */
public class CidadeDAO {

    private Connection conn;

    public CidadeDAO() throws Exception {
        try {

            this.conn = ConnectionFactory.abrirconexao();
            System.out.println("Conectado com sucesso");

        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }

    }

    public int salvarCidade(String nomeCidade) {

        int idCidade = 0;
        PreparedStatement stmt = null;

        ResultSet rs = null;

        String verificarCidade = "select idcidade from cidade where nomecidade = ?";
        String insertCidade = "insert into cidade(nomecidade)values(?) returning idcidade";

        try {

            stmt = this.conn.prepareStatement(verificarCidade);
            stmt.setString(1, nomeCidade);

            rs = stmt.executeQuery();

            // Se já existir uma cidade com esse nome, retorna o id da cidade
            // Se não -> inserir uma nova cidade no banco de dados e retornar o id da nova cidade
            if (rs.next()) {
                idCidade = rs.getInt("idcidade");
            } else {

                stmt = this.conn.prepareStatement(insertCidade);
                stmt.setString(1, nomeCidade);

                rs = stmt.executeQuery();

                if (rs.next()) {
                    idCidade = rs.getInt("idcidade");
                }
            }

        } catch (Exception e) {
            System.out.println("Erro ao salvar cidade\nErro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão com o BD\nErro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
        return idCidade;

    }

    public List<Object> listarCidades(int idCidade) {

        List<Object> listaCidades = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select * from cidade";

        try {

            stmt = this.conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Cidade oCidade = new Cidade();

                oCidade.setIdCidade(rs.getInt("idcidade"));
                oCidade.setNomeCidade(rs.getString("nomecidade"));

                listaCidades.add(oCidade);
            }

        } catch (Exception e) {
            System.out.println("Erro ao listar cidades\nErro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                ConnectionFactory.fechar(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão com o BD\nErro: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return listaCidades;
    }
    
    public Object carregarCidade(int idCidade){
        
        Cidade oCidade = null;
        
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        String selectCidade = "select * from cidade where idcidade = ?";
        
        try {
            
            stmt = this.conn.prepareStatement(selectCidade);
            
            stmt.setInt(1, idCidade);
            rs = stmt.executeQuery();
            
            if(rs.next()){
                oCidade = new Cidade();
                
                oCidade.setIdCidade(rs.getInt("idcidade"));
                oCidade.setNomeCidade(rs.getString("nomecidade"));
            }
            
        } catch (Exception e) {
            System.out.println("Erro ao carregar cidade \nErro: "+e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                
                ConnectionFactory.fechar(conn, stmt, rs);
                
            } catch (Exception e) {
                System.out.println("Erro ao fechar conexão com o BD\nErro: "+e.getMessage());
                e.printStackTrace();
            }
        }
        
        return oCidade;
    }
}
