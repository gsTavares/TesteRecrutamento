CREATE TABLE cidade(

idcidade serial not null,
nomecidade varchar(100) not null,

CONSTRAINT pk_cidade PRIMARY KEY (idcidade)
);

CREATE TABLE pessoa(

idpessoa serial not null,
idcidade integer not null,
nomepessoa varchar(300) not null,
datanascimentopessoa date not null,
cpfpessoa varchar(14) not null,


CONSTRAINT pk_pessoa PRIMARY KEY (idpessoa),
CONSTRAINT fk_idcidade FOREIGN KEY (idcidade) REFERENCES cidade(idcidade)


);
