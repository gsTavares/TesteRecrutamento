/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.testerecrutamento.model;

import java.util.Date;

/**
 *
 * @author PICHAU
 */
public class Pessoa {
    private int idPessoa;
    private int idCidade;
    private String nomePessoa;
    private Date dataNascimentoPessoa;
    private String cpfPessoa;
    
    public Pessoa(){
        
    }

    public Pessoa(int idPessoa, int idCidade, String nomePessoa, Date dataNascimentoPessoa, String cpfPessoa) {
        this.idPessoa = idPessoa;
        this.idCidade = idCidade;
        this.nomePessoa = nomePessoa;
        this.dataNascimentoPessoa = dataNascimentoPessoa;
        this.cpfPessoa = cpfPessoa;
    }

    /**
     * @return the idPessoa
     */
    public int getIdPessoa() {
        return idPessoa;
    }

    /**
     * @param idPessoa the idPessoa to set
     */
    public void setIdPessoa(int idPessoa) {
        this.idPessoa = idPessoa;
    }

    /**
     * @return the idCidade
     */
    public int getIdCidade() {
        return idCidade;
    }

    /**
     * @param idCidade the idCidade to set
     */
    public void setIdCidade(int idCidade) {
        this.idCidade = idCidade;
    }

    /**
     * @return the nomePessoa
     */
    public String getNomePessoa() {
        return nomePessoa;
    }

    /**
     * @param nomePessoa the nomePessoa to set
     */
    public void setNomePessoa(String nomePessoa) {
        this.nomePessoa = nomePessoa;
    }

    /**
     * @return the dataNascimentoPessoa
     */
    public Date getDataNascimentoPessoa() {
        return dataNascimentoPessoa;
    }

    /**
     * @param dataNascimentoPessoa the dataNascimentoPessoa to set
     */
    public void setDataNascimentoPessoa(Date dataNascimentoPessoa) {
        this.dataNascimentoPessoa = dataNascimentoPessoa;
    }

    /**
     * @return the cpfPessoa
     */
    public String getCpfPessoa() {
        return cpfPessoa;
    }

    /**
     * @param cpfPessoa the cpfPessoa to set
     */
    public void setCpfPessoa(String cpfPessoa) {
        this.cpfPessoa = cpfPessoa;
    }
    
    
    
    
    
}
